msg::debug "ppa manager"
PACKAGE_MANAGER="add-apt-repository"
install="--yes"
remove="--yes --remove"
