cleanText(){
	local originalText="?u=https:%2F%2Fexternal-preview.redd.it%2FCdsmdP-CNYxgFUAc3DyRoEX65KpQLoHM4Es_qltfOno.jpg%3Fauto%3Dwebp%26s%3D3c1c74d170de0bd870b85be1643a3bcccb2ecc36&f=1&nofb=1"
	local subpart="${originalText/"%3F"/"?"}"
	echo '$subpart'
	echo $subpart
	local first_part=$( echo "${subpart}" | cut -d'?' -f2 )
	echo '$first_part'
	echo $first_part
	local second_part=$( echo "${subpart}" | cut -d'?' -f3 )
	echo '$second_part'
	echo $second_part

local testValue=$(echo "${subpart}"| perl -MURI::file -e 'print URI::file->new(<STDIN>)')

	echo '$second_part'
	echo $second_part

local second_part_clean=$(echo ''"${second_part}"'' | perl -pe 's/\%(\w\w)/chr hex $1/ge')

	local new_text="?""${first_part}"?"${second_part_clean}"

	echo $new_text


	find src/backgrounds -name "*$new_text"
}


cleanText