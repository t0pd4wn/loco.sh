#!bin/bash
#-------------------------------------------------------------------------------
# custom.sh | profile custom functions (execute as root)
#-------------------------------------------------------------------------------

#################
# all OS
#################
install_last(){
    echo "To use this profile correctly, set your terminal as a startup application."
    echo "See details in ~/.loco_startup."
}